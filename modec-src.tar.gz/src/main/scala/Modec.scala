

package modec

import ap.SimpleAPI
import SimpleAPI.ProverStatus
import ap.basetypes.IdealInt
import ap.parser._
import ap.terfor.ConstantTerm
import ap.terfor.linearcombination.LinearCombination

import scala.collection.mutable.ArrayBuffer

object Modec {

  object NullStream extends java.io.OutputStream {
    def write(b : Int) = {}
  }

  val enableAssert = false

  private object NotMonadic extends Exception

}

/**
 * Compute the monadic decomposition of a Presburger formula
 */
class Modec(f : IFormula) {
  import Modec._
  import IExpression._

  private val variables = SymbolCollector constantsSorted f

  val result : Option[IFormula] =
    SimpleAPI.withProver(enableAssert = Modec.enableAssert) { p =>
      import p._

      val eqX = createConstantRaw("X")
      val eqY = createConstantRaw("Y")

      addConstantsRaw(variables)

      def decomp(f : IFormula, vars : List[ConstantTerm]) : IFormula = {
        val fVars = SymbolCollector constants f
        (vars filter fVars) match {
          case List() | List(_) =>
            // formula is already monadic
            f

          case x :: restVars => {
            def fRepl(t : ITerm) = ConstantSubstVisitor(f, Map(x -> t))
            val xEqvRel =
              projectAll(fRepl(eqX) <===> fRepl(eqY), List(eqX, eqY))

            val cl = new EqvIndexChecker(xEqvRel, eqX, eqY)

/*
            println(xEqvRel)
            if (cl.hasFiniteIndex)
              println("Index checker: Decomposable!")
            else
              println("Index checker: Not decomposable!")
 */

            val maybeClasses =
              Console.withOut(NullStream) {
                new EqvClassifier(xEqvRel, eqX, eqY).result
              }

            assert(cl.hasFiniteIndex == maybeClasses.isDefined)

            if (maybeClasses.isEmpty)
              throw NotMonadic

            val Some(classes) = maybeClasses
            or(for ((el, xElements) <- classes;
                    remF = simplify(
                           SimplifyingConstantSubstVisitor(f, Map(x -> i(el))));
                    res = ConstantSubstVisitor(xElements, Map(eqX -> i(x))) &&&
                          decomp(remF, restVars);
                    if !res.isFalse)
               yield res)
          }
        }
      }

      try {
        val res = decomp(f, variables.toList)

        if (enableAssert) scope {
          ?? (res <===> f)
          assert(??? == ProverStatus.Valid)
        }

        Some(res)
      } catch {
        case NotMonadic => None
      }
    }

}
