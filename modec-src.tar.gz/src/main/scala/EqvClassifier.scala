

package modec

import ap.SimpleAPI
import SimpleAPI.ProverStatus
import ap.basetypes.IdealInt
import ap.parser._
import ap.terfor.ConstantTerm
import ap.terfor.linearcombination.LinearCombination

import scala.collection.mutable.ArrayBuffer

/**
 * Compute the equivalence classes of an equivalence relation defined in
 * Presburger arithmetic.
 */
class EqvClassifier(rawEqvRel : IFormula,
                    v1 : ConstantTerm, v2 : ConstantTerm) {
  import IExpression._

  private val V1Sum = SymbolSum(v1)
  private val VarSum = SymbolSum(v(0))

  /**
   * Either the equivalence classes, each with a representative element,
   * or None in case there are infinitely many classes.
   */
  val result : Option[Seq[(IdealInt, IFormula)]] =
    SimpleAPI.withProver(enableAssert = Modec.enableAssert) { p =>
      import p._

      addConstantRaw(v1)
      addConstantRaw(v2)

      val eqvRel = simplify(rawEqvRel)

      println
      println("Computing classes for: " + pp(eqvRel))

      val classes = new ArrayBuffer[(IdealInt, IFormula)]
      def addClass(el : IdealInt) : IFormula = {
        val elements = simplify(SimplifyingConstantSubstVisitor(eqvRel,
                                                           Map(v2 -> i(el))))
        classes += ((el, elements))
        println("Found class: " + pp(elements))
        elements
      }

      // First search for infinite classes

      scope {
        val posFlag = createBooleanVariable("pf")
        def instr(f : IFormula) = instrumentFormula(Transform2NNF(f), posFlag)

        !! (instr(eqvRel))

        while (??? == ProverStatus.Sat) {
          // println(partialModel)
          val elements = addClass(eval(v2))
          !! (instr(!elements))
          !! (!ConstantSubstVisitor(elements, Map(v1 -> i(v2))))
        }
      }
      
      // Check boundedness of the remaining relation
      // TODO: How to do this more efficiently?

      val remaining =
        eqvRel & and(for ((_, c) <- classes)
                     yield (!c & !ConstantSubstVisitor(c, Map(v1 -> i(v2)))))

      val finiteness = scope {
        ?? (ex(bound => all((x, y) =>
                 ConstantSubstVisitor(remaining, Map(v1 -> x, v2 -> y)) ==>
                   (x >= -bound & x <= bound))))
        ??? == ProverStatus.Valid
      }

      if (finiteness) scope {
        // Compute the finitely many remaining finite classes

        !! (remaining)

        while (??? == ProverStatus.Sat) {
          // println(partialModel)
          val elements = addClass(eval(v2))
          !! (!elements)
          !! (!ConstantSubstVisitor(elements, Map(v1 -> i(v2))))
        }

        println("There are " + classes.size + " equivalence classes")

        Some(classes.toList)
      } else {
        println("There are infinitely many finite classes")
        None
      }
    }

  //////////////////////////////////////////////////////////////////////////////

  private def instrumentFormula(f : IFormula,
                                posFlag : IFormula) : IFormula = f match {
    case IBinFormula(j, f1, f2) =>
      IBinFormula(j,
                  instrumentFormula(f1, posFlag),
                  instrumentFormula(f2, posFlag))
    case EqZ(V1Sum(coeff, _)) if !coeff.isZero =>
      false
    case f@EqZ(_) =>
      f
    case INot(EqZ(t@V1Sum(coeff, _))) if coeff.signum > 0 =>
      (t < 0 & !posFlag) | (t > 0 & posFlag)
    case INot(EqZ(t@V1Sum(coeff, _))) if coeff.signum < 0 =>
      (t < 0 & posFlag) | (t > 0 & !posFlag)
    case f@INot(EqZ(_)) =>
      f
    case f@GeqZ(V1Sum(coeff, _)) if coeff.signum > 0 =>
      f & posFlag
    case f@GeqZ(V1Sum(coeff, _)) if coeff.signum < 0 =>
      f & !posFlag
    case f@GeqZ(_) =>
      f
    case f@INot(GeqZ(V1Sum(coeff, _))) if coeff.signum > 0 =>
      f & !posFlag
    case f@INot(GeqZ(V1Sum(coeff, _))) if coeff.signum < 0 =>
      f & posFlag
    case f@INot(GeqZ(_)) =>
      f
    case f@IQuantified(Quantifier.ALL, INot(EqZ(VarSum(c, _)))) if !c.isZero =>
      f
    case f@IQuantified(Quantifier.EX, EqZ(VarSum(c, _))) if !c.isZero =>
      f
  }

}
