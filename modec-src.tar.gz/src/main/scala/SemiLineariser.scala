
package modec

import ap.SimpleAPI
import SimpleAPI.ProverStatus
import ap.basetypes.IdealInt
import ap.parser._
import ap.terfor.ConstantTerm
import ap.terfor.linearcombination.LinearCombination

import scala.collection.mutable.ArrayBuffer

object SemiLineariser {

  type Progression = (Seq[IdealInt], Seq[Seq[IdealInt]])
  type Progressions = Seq[Progression]

  def pp(p : Progression) : String = {
    "(" + (p._1 mkString ", ") + ")" +
    (for (vec <- p._2) yield (" + (" + (vec mkString ", ") + ")*")).mkString
  }

}

/**
 * Represent a Presburger formula as a union of arithmetic progressions
 * (currently does not handle equations or divisibility)
 */
class SemiLineariser(originalFormula : IFormula,
                     variables : Seq[ConstantTerm]) {

  import SemiLineariser._
  import IExpression._

  private val dimension = variables.size

  //////////////////////////////////////////////////////////////////////////////

  val result : Progressions =
    SimpleAPI.withProver(enableAssert = true) { p =>
      import p._
      implicit val _ = p

      addConstantsRaw(variables)

      (for (disjunct <- DNFConverter qeDNF originalFormula) yield {
        val conjuncts = LineariseVisitor(disjunct, IBinJunctor.And)
        assert(conjuncts forall { case GeqZ(_) => true; case _ => false })
        linearise(conjuncts map (_.asInstanceOf[IIntFormula]))
      }).flatten
    }

  println
  println("Progressions:")
  for (p <- result)
    println(pp(p))

  //////////////////////////////////////////////////////////////////////////////

  /**
   * Convert a conjunction of inequalities to arithmetic progressions
   */
  private def linearise(ineqs : Seq[IIntFormula])
                       (implicit p : SimpleAPI) : Progressions = {
    import p._

    println
    println("Handling: " + (ineqs map (pp(_)) mkString ", "))

    // Check for independent vectors that are increasing for all inequalities

    val (increasingVectors, cone) = scope {
      val nonConstIneqs = for (GeqZ(t) <- ineqs) yield GeqZ(nonConstSum(t))
      !! (and(nonConstIneqs))

      val increasingVectors = new ArrayBuffer[Seq[IdealInt]]
      var cone : IFormula = (variables === 0)

      var cont = true
      while (cont) {

        scope {
          !! (!cone)

          ??? match {
            case ProverStatus.Sat => {
              val newVector = for (c <- variables) yield eval(c)
              increasingVectors += newVector

              // add the new vector to the cone
              val primedVars = createConstants(variables.size)
              val lambda = createConstant("lambda", Sort.Nat)

              val subst = (variables zip primedVars).toMap

              cone =
                projectEx(ConstantSubstVisitor(cone, subst) &
                          (variables === (primedVars +++
                           (for (c <- newVector) yield c * lambda))), variables)
            }
            case ProverStatus.Unsat =>
              cont = false
          }
        }
      }

      (increasingVectors.toList, cone)
    }

    val subsumedPoints = scope {
      val primedVars1 = createConstants(variables.size)
      val primedVars2 = createConstants(variables.size)
      val subst1 = (variables zip primedVars1).toMap
      val subst2 = (variables zip primedVars2).toMap
      val primedCone = ConstantSubstVisitor(cone, subst1) & !(primedVars1 === 0)
      val primedIneqs = ConstantSubstVisitor(and(ineqs), subst2)
      projectEx(primedCone & primedIneqs &
                (variables === primedVars1 +++ primedVars2), variables)
    }

    // Find the minimal points of the set

    val minimalPoints = scope {
      val points = new ArrayBuffer[Seq[IdealInt]]

      !! (and(ineqs))
      !! (!subsumedPoints)

      while (??? == ProverStatus.Sat) {
        val newPoint = for (c <- variables) yield eval(c)
        points += newPoint
        !! (!(variables === (newPoint map (i(_)))))
      }

      points.toList
    }

    for (point <- minimalPoints) yield (point, increasingVectors)
  }

  private def nonConstSum(t : ITerm) : ITerm = t match {
    case IPlus(t1, t2)     => IPlus(nonConstSum(t1), nonConstSum(t2))
    case ITimes(coeff, t2) => ITimes(coeff, nonConstSum(t2))
    case _ : IIntLit       => 0
    case t : IConstant     => t
  }

}
