package modec

import ap.SimpleAPI
import SimpleAPI.ProverStatus
import ap.basetypes.{IdealInt, IdealRat}
import ap.parser._
import ap.terfor.ConstantTerm
import ap.terfor.linearcombination.LinearCombination

import scala.collection.mutable.ArrayBuffer

/**
 * Compute whether a given quantifier-free equivalence relation has
 * finite index.
 */
class EqvIndexChecker(rawEqvRel : IFormula,
                      v1 : ConstantTerm, v2 : ConstantTerm) {
  import IExpression._

  private val V1Sum = SymbolSum(v1)
  private val V2Sum = SymbolSum(v2)
  private val VarSum = SymbolSum(v(0))

  val hasFiniteIndex : Boolean =
    SimpleAPI.withProver(enableAssert = Modec.enableAssert) { p =>
      import p._

      addConstantRaw(v1)
      addConstantRaw(v2)

      val c = createConstant("c")
      val d = createConstant("d")

      val negEqvRel = Transform2NNF(simplify(~rawEqvRel))

//      println
//      println("Negated relation: " + pp(negEqvRel))

      val angl = angles(negEqvRel)
      val relevantAngles =
        (for (a <- angl ++ Set(IdealRat.ZERO, IdealRat.ONE);
              if a >= IdealRat.ZERO && a <= IdealRat.ONE)
         yield a).toList.sorted

//      println(relevantAngles)
     
      val charFormula =
        and(for (Seq(a1, a2) <- relevantAngles sliding 2)
            yield doubleSubst(negEqvRel, a1, a2, 1)) |
        and(for (Seq(a1, a2) <- relevantAngles sliding 2)
            yield doubleSubst(negEqvRel, a1, a2, -1))

      val divCoeff = IdealInt lcm divCoefficients(negEqvRel)

      !! ((c > 0 & d > 0) | (c < 0 & d < 0))

      val substCharFormula =
        ConstantSubstVisitor(charFormula,
                             Map(v1 -> c, v2 -> (c - d*divCoeff)))

      !! (substCharFormula)

      ??? == ProverStatus.Unsat
    }

  private def angles(f : IFormula) : Set[IdealRat] = f match {
    case IBinFormula(_, f1, f2) =>
      angles(f1) | angles(f2)
    case INot(f) =>
      angles(f)
    case EqZ(V1Sum(v1Coeff, V2Sum(v2Coeff, _))) =>
      if (v2Coeff.isZero) Set() else Set(IdealRat(-v1Coeff, v2Coeff))
    case GeqZ(V1Sum(v1Coeff, V2Sum(v2Coeff, _))) =>
      if (v2Coeff.isZero) Set() else Set(IdealRat(-v1Coeff, v2Coeff))
    case IQuantified(Quantifier.ALL, INot(EqZ(_))) =>
      Set()
    case IQuantified(Quantifier.EX, EqZ(_)) =>
      Set()
  }

  private def divCoefficients(f : IFormula) : Iterator[IdealInt] = f match {
    case IBinFormula(_, f1, f2) =>
      divCoefficients(f1) ++ divCoefficients(f2)
    case INot(f) =>
      divCoefficients(f)
    case EqZ(_) =>
      Iterator.empty
    case GeqZ(_) =>
      Iterator.empty
    case IQuantified(Quantifier.ALL, INot(EqZ(VarSum(c, _)))) =>
      Iterator single c.abs
    case IQuantified(Quantifier.EX, EqZ(VarSum(c, _))) =>
      Iterator single c.abs
  }

  private def doubleSubst(f : IFormula,
                          a1 : IdealRat, a2 : IdealRat,
                          neg : IdealInt) : IFormula = f match {
    case Conj(f1, f2) =>
      doubleSubst(f1, a1, a2, neg) &&& doubleSubst(f2, a1, a2, neg)
    case Disj(f1, f2) =>
      doubleSubst(f1, a1, a2, neg) ||| doubleSubst(f2, a1, a2, neg)
    case EqZ(V1Sum(v1Coeff, V2Sum(v2Coeff, _))) =>
      v1Coeff * a1.num + v2Coeff * a1.denom == 0 &&
      v1Coeff * a2.num + v2Coeff * a2.denom == 0
    case INot(EqZ(V1Sum(v1Coeff, V2Sum(v2Coeff, _)))) =>
      (v1Coeff * a1.num + v2Coeff * a1.denom >= 0 &&
       v1Coeff * a2.num + v2Coeff * a2.denom >= 0) ||
      (v1Coeff * a1.num + v2Coeff * a1.denom <= 0 &&
       v1Coeff * a2.num + v2Coeff * a2.denom <= 0)
    case GeqZ(V1Sum(v1Coeff, V2Sum(v2Coeff, _))) =>
      (v1Coeff * a1.num + v2Coeff * a1.denom) * neg >= 0 &&
      (v1Coeff * a2.num + v2Coeff * a2.denom) * neg >= 0
    case INot(GeqZ(V1Sum(v1Coeff, V2Sum(v2Coeff, _)))) =>
      (v1Coeff * a1.num + v2Coeff * a1.denom) * neg <= 0 &&
      (v1Coeff * a2.num + v2Coeff * a2.denom) * neg <= 0
    case f =>
      f
  }
}
