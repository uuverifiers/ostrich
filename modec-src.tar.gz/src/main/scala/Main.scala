

package modec

import ap.SimpleAPI
import ap.basetypes.IdealInt
import ap.parser._
import ap.terfor.ConstantTerm

object Main extends App {

  SimpleAPI.withProver(enableAssert = true) { p =>
    import p._
    import IExpression._

    val x@IConstant(xc) = createConstant("x")
    val y@IConstant(yc) = createConstant("y")
    val z@IConstant(zc) = createConstant("z")

    for (f <- List((x >= 0) <===> (y >= 10),
                   (x + y >= 0 & x >= 0),
                   x + y >= 0 & x >= 0 & y >= 0,
                   x + y <= 20 & x >= 0 & y >= 0,
                   x*2 + y <= 20 & x >= 0 & y >= 0,
                   x*2 + y <= 20 & y >= 0,
                   x === y + 1,
                   x === y + 1 & x >= 0 & y <= 20,
                   x === y + 1 & x >= 0 & y <= 20 & (x % 3 === 1),
                   ((x === y * 2) & 0 <= y & y < 5),
                   ((x === y * 2) & 0 <= y & y < 5) | x > y,
                   ((x === y * 2) & 0 <= y & y < 5) & x > y,
                   x > y & y >= 0 & y < 10,
                   x === y & (x >= 0 & y >= 0 & x <= 100 & y <= 100),
                   x + y + z <= 10,
                   x >= 0 & y >= 0 & z >= 0 & x + y + z <= 10)) {
      println
      println("Decomposing " + pp(f))
      (new Modec(f)).result match {
        case Some(g) => println(pp(g))
        case None    => println("Not decomposable")
      }
    }

    {
      val rel = (x % 2) === (y % 2)
      val cl1 = new EqvClassifier(rel, xc, yc)
      val cl2 = new EqvIndexChecker(rel, xc, yc)
      assert(cl1.result.isDefined == cl2.hasFiniteIndex)
      if (cl2.hasFiniteIndex)
        println("Index checker: Decomposable!")
      else
        println("Index checker: Not decomposable!")
    }

/*
    Tests for computing equivalence classes

    {
    def f(x : ITerm, y : ITerm) = (x >= 0) <===> (y >= 10)
    new EqvClassifier(all(z => (f(x,z) <===> f(y,z)) & (f(z,x) <===> f(z,y))),
                      xc, yc)
    }

    {
    def f(x : ITerm, y : ITerm) = (x + y >= 0 & x >= 0)
    new EqvClassifier(all(z => (f(x,z) <===> f(y,z)) & (f(z,x) <===> f(z,y))),
                      xc, yc)
    }

    {
    def f(x : ITerm, y : ITerm) = (x + y >= 0 & x >= 0 & y >= 0)
    new EqvClassifier(all(z => (f(x,z) <===> f(y,z)) & (f(z,x) <===> f(z,y))),
                      xc, yc)
    }

    {
    def f(x : ITerm, y : ITerm) = (x === y + 1)
    new EqvClassifier(all(z => (f(x,z) <===> f(y,z)) & (f(z,x) <===> f(z,y))),
                      xc, yc)
    }

    {
    def f(x : ITerm, y : ITerm) = (x === y + 1 & x >= 0 & y <= 20)
    new EqvClassifier(all(z => (f(x,z) <===> f(y,z)) & (f(z,x) <===> f(z,y))),
                      xc, yc)
    }

    {
    def f(x : ITerm, y : ITerm) = (x === y + 1 & x >= 0 & y <= 20 & (x % 3 === 1))
    new EqvClassifier(all(z => (f(x,z) <===> f(y,z)) & (f(z,x) <===> f(z,y))),
                      xc, yc)
    }
*/

/*
    Tests for semi-linear representation

    new SemiLineariser((x + y >= 5) & (x >= 0), List(xc, yc))
    new SemiLineariser((x + y >= 5) & (x >= 0) & y <= 10, List(xc, yc))
*/
  }
}
